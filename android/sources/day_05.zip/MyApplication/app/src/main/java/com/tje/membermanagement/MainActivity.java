package com.tje.membermanagement;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    MemberDbHelper memberDbHelper;

    Button btn_add;
    Button btn_update;
    Button btn_delete;

    TextView tv_no_member;
    RecyclerView memberRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        memberDbHelper = new MemberDbHelper(this);

        btn_add = findViewById(R.id.btn_add);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        tv_no_member = findViewById(R.id.tv_no_member);
        memberRecyclerView = findViewById(R.id.memberRecyclerView);


        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MemberAddActivity.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    // p 129에 액티비티의 생명주기

    // 화면이 복귀될 때 아래의 것을 체크하여 보일건 보이게, 안보일건 안보이게 한다.
    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "Count : " + memberDbHelper.count(), Toast.LENGTH_SHORT).show();
        if( memberDbHelper.count() == 0 ) {
            tv_no_member.setVisibility(View.VISIBLE);
            memberRecyclerView.setVisibility(View.GONE);
        } else {
            tv_no_member.setVisibility(View.GONE);
            memberRecyclerView.setVisibility(View.VISIBLE);
        }
    }
}
